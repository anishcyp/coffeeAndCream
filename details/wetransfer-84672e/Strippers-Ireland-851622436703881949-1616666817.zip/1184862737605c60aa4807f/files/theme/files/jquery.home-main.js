$(document).ready(function()
        /* ==================== Pre Loader ==================== */
        {setTimeout(function() {
            $('#loading').fadeOut('slow', function() {});
        }, 300);
		
		/* ==================== Dynamic Header Height ==================== */
		$('.dynamic-head .full-screen').css({"padding-top" : $(".top-bar").height() + "px"});
		
		/* ==================== Home Slider ==================== */
		$(function() {
            var owl = $(".home-slider");
            owl.owlCarousel({
                pagination: false,
                navigation: false,
				slideSpeed : 300,
				items : 1,
				autoPlay: 9000,
				loop: true,
				itemsDesktop : false,
				itemsDesktopSmall : false,
				itemsTablet: false,
				itemsMobile : false,
				afterAction: afterAction
            });
            // Custom navigation
            $(".slide-next").click(function() {
                owl.trigger('owl.next');
            })
            $(".slide-prev").click(function() {
                owl.trigger('owl.prev');
            })
        });
		
		function changeClass(slide){

        setTimeout(function(){

         $(".owl-item").each(function(){
          if ($(this).index() === slide){
            $(this).addClass("active");
          } else{
           $(this).removeClass("active");
          }
        });

    },500);
  }

function afterAction(){
  changeClass(this.owl.currentItem);
}

        /* ==================== Scroller Menu toggle ==================== */
        $('#toggle').click(function(e) {
            e.stopPropagation();
        }); 
		$('html').click(function(e) {
            if (!$('.toggle').is($(e.target))) {
                $('#toggle').prop("checked", false);
            }
        });

        /* ==================== Multi Menu toggle ==================== */
        $('.hamburger').click(function() {
            $('body').toggleClass("menu-open");
        });
		
        /* ==================== Top bar height effect one page scroller layout ==================== */
        $(window).bind("scroll", function() {
            if ($(this).scrollTop() > 300) {
                $(".top-bar").removeClass("tb-large").addClass("tb-small animated fadeInDown");
            } else {
                $(".top-bar").removeClass("tb-small animated fadeInDown").addClass("tb-large");
            }
        });

        $('#live-tog').click(function() {
		  $('body').toggleClass("scroller-menu-on");
		    $('body').toggleClass("scroller-menu-off");
		});
		
		$('.wft-btn').click(function() {
		  $('body').toggleClass("live-menu-on");
		});


        /* ==================== Work slider ==================== */
        $(function() {
            var owl = $(".work-slider");
            owl.owlCarousel({
                pagination: false,
                navigation: false,
                items: 3,
                itemsDesktop: [1000, 3],
                itemsTablet: [600, 2],
                itemsMobile: [321, 1],
            });
            // Custom navigation
            $(".work-next").click(function() {
                owl.trigger('owl.next');
            })
            $(".work-prev").click(function() {
                owl.trigger('owl.prev');
            })
        });
		
		/* ==================== Testimonial slider ==================== */
        $(function() {
            var owl = $(".wft-testimonial-slider");
            owl.owlCarousel({
                pagination: false,
                navigation: false,
				slideSpeed : 300,
				items : 1, 
				itemsDesktop : false,
				itemsDesktopSmall : false,
				itemsTablet: false,
				itemsMobile : false			
            });
            // Custom navigation
            $(".test-next").click(function() {
                owl.trigger('owl.next');
            })
            $(".test-prev").click(function() {
                owl.trigger('owl.prev');
            })
        });
		
        /* ==================== Gallery Mobile ==================== */
      	$('.imageGallery').each(function(){
      	  if ($(this).children('div').length <= 12) {
      	    $(this).children('div').addClass('fullwidth-mobile');
      	  }
      	});

        /* ==================== Scrollto ==================== */
        $(function() {
            $('.scrollto').bind('click.scrollto', function(e) {
                e.preventDefault();
                var target = this.hash,
                    $target = $(target);
                $('html, body').stop().animate({
                    'scrollTop': $target.offset().top - 0
                }, 900, 'swing', function() {
                    window.location.hash = target;
                });
            });
        });

        /* ==================== Equal height ==================== */
        $('.equal').children('.col').equalizeHeight(); $(window).resize(function() {
            $('.equal').children('.col').equalizeHeight();
            setTimeout(function() {
                $('.equal').children('.col').equalizeHeight();
            }, 100);
            setTimeout(function() {
                $('.equal').children('.col').equalizeHeight();
            }, 400);
            setTimeout(function() {
                $('.equal').children('.col').equalizeHeight();
            }, 1400);
            setTimeout(function() {
                $('.equal').children('.col').equalizeHeight();
            }, 2400);
        }); setTimeout(function() {
            $(window).trigger('resize scroll');
        }, 1000); setTimeout(function() {
            $(window).trigger('resize scroll');
        }, 3000); $(window).load(function() {
            $('.equal').children('.col').equalizeHeight();
            $(window).trigger('resize scroll');
            setTimeout(function() {
                $('.equal').children('.col').equalizeHeight();
            }, 1000);
            setTimeout(function() {
                $('.equal').children('.col').equalizeHeight();
            }, 1300);
        });

        /* ==================== one page nav ==================== */
        $('#nav').onePageNav({
            currentClass: 'current',
            changeHash: false,
            scrollSpeed: 1200
        });
		
	});