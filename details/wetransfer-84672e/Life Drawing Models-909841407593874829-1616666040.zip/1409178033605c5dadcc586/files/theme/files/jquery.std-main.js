$(document).ready(function()
        /* ==================== Pre Loader ==================== */
        {setTimeout(function() {
            $('#loading').fadeOut('slow', function() {});
        }, 300);
		
		/* ==================== Dynamic Header Height ==================== */
		$('.dynamic-head #weebly_sections').css({"padding-top" : $(".top-bar").height() + "px"});
		
        /* ==================== Scroller Menu toggle ==================== */
        $('#toggle').click(function(e) {
            e.stopPropagation();
        }); 
		$('html').click(function(e) {
            if (!$('.toggle').is($(e.target))) {
                $('#toggle').prop("checked", false);
            }
        });

        /* ==================== Multi Menu toggle ==================== */
        $('.hamburger').click(function() {
            $('body').toggleClass("menu-open");
        });

        /* ==================== Top bar height effect one page scroller layout ==================== */
        $(window).bind("scroll", function() {
            if ($(this).scrollTop() > 300) {
                $(".top-bar").removeClass("tb-large").addClass("tb-small animated fadeInDown");
            } else {
                $(".top-bar").removeClass("tb-small animated fadeInDown").addClass("tb-large");
            }
        });
		
		$('#live-tog').click(function() {
		  $('body').toggleClass("scroller-menu-on");
		    $('body').toggleClass("scroller-menu-off");
		});
		
		$('.wft-btn').click(function() {
		  $('body').toggleClass("live-menu-on");
		});
		
		/* ==================== Gallery Mobile ==================== */
      	$('.imageGallery').each(function(){
      	  if ($(this).children('div').length <= 25) {
      	    $(this).children('div').addClass('fullwidth-mobile');
      	  }
      	});

        /* ==================== Scrollto ==================== */

		$(".back-top").hide();

        // fade in #scroll-top
        $(window).scroll(function () {
          if ($(this).scrollTop() > 150) {
            $('.back-top').fadeIn();
           } else {
            $('.back-top').fadeOut();
           }
        });
	
        $(function() {
            $('.scrollto').bind('click.scrollto', function(e) {
                e.preventDefault();
                var target = this.hash,
                    $target = $(target);
                $('html, body').stop().animate({
                    'scrollTop': $target.offset().top - 0
                }, 900, 'swing', function() {
                    window.location.hash = target;
                });
            });
        });
		
	});